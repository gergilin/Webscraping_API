Before starting
1 Make Sure that you have Node.js installed and "node" and "npm" is a known word for your console.
2 this program only work on Windows
3 in case of any trouble running "Start_Http.bat", go to "teste" directory, open console and run "npm install -g http-server", you should be able to run "Start_Http.bat" now.

Accessing just API
1 Execute "Start_backend.bat".
2 In your browser, access "http://localhost:12345/api/scrape?keyword=YourKeyword".
3 Change YourKeyword for what you want to search.

Accessing website
1 Execute "Start_backend.bat" and "Start_Http.bat".
2 In your browser, access "http://localhost:8080/Main.html".
3 Write what you want to search and press "Search".