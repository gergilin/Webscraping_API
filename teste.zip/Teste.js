const cheerio = require('cheerio');
const axios = require('axios');
const express = require('express');
const cors = require('cors');
//script for webscrapping, "reference" is the url reference for the page. 
async function webscrap(reference) {
    //making sure that the response code will be correct
    code = 1000
    while(code >= 500){
        try{
            //Get request using Axios
            var response = await axios.get(reference);
            code = 200;
            //Loading the HTML page using cheerio
            const HTML_DATA_CRUDE = cheerio.load(response.data);
            var HTML_DATA = [];
            //Select titles,prices,stars and image URLS using 'find' method.
            HTML_DATA_CRUDE(".a-section.a-spacing-base").each((index,element)=>{
                var Title = HTML_DATA_CRUDE(element).find(".a-size-base-plus.a-color-base.a-text-normal").text().trim()
                var Price = HTML_DATA_CRUDE(element).find(".a-offscreen").text().trim()
                var Stars = HTML_DATA_CRUDE(element).find(".a-icon-alt").text().trim()
                var Url = HTML_DATA_CRUDE(element).find(".s-image").attr('src')
                
                //Creating a object to store the gathered information.
                var gathered_info = {
                        title:Title,
                        price:Price,
                        stars:Stars,
                        url:Url
                    } 
                //push object in HTML_DATA
                HTML_DATA.push(gathered_info)
                }
            )
            //return the HTML_DATA
            return HTML_DATA;
        }
        catch(error){
            //console.error('Error during web scraping:', error.message);
            //in case of error due server problems(that are constant), the script will await 500 milliseconds and try again.
            await new Promise(resolve => setTimeout(resolve, 500));
        }

    }
    
}
//initialize api
const app = express();
const port = 12345;
app.use(cors())
app.get(
    //just initializing with the path and an asynchronous function
    "/api/scrape",cors(), async (req,res)=>{
            try{
            //Setting the keyword
            const keyword = req.query.keyword;   
            if (!keyword) {
                //checking if the keyword was given
                return res.status(400).send({ error: 'Missing keyword parameter' });
            }
            //calling the webscrap function
            const result = await webscrap("https://www.amazon.com.br/s?k="+keyword)
            res.status(200).send({
                url:"https://www.amazon.com.br/s?k="+keyword,
                result:result
            })
        }
        catch(error){
            //in case of error, it will be flagged.
            console.error('Error during scraping:', error.message);
            res.status(500).json({ error: 'Internal server error' });
        }
    }
)
app.listen(port,()=>{
    //hey, im now listening to 
    console.log('Hey,im now listening at 127.0.0.1:'+port+"!");
})
async function main() {
    var resultado = await webscrap("https://www.amazon.com.br/s?k=fone+de+ouvido")
    console.log(resultado)
}